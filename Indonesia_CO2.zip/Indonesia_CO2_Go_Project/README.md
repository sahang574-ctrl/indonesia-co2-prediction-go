# Indonesia CO2 emissions analysis

This Go project analyses the supplied 1970–2022 national CO2 series for Indonesia (IDN, indicator EN.GHG.CO2.MT.CE.AR5). The source values are in Mt CO2e and exclude land use, land-use change and forestry.

## Project files

| Path | Contents |
|---|---|
| `data/indonesia_co2.csv` | The 53 source observations supplied with the assignment |
| `main.go`, `analysis.go`, `plots.go` | CSV validation, modelling, evaluation and SVG generation |
| `district.go` | Coordinate matching and annual district summaries |
| `main_test.go` | Checks for OLS, data coverage, leakage and district matching |
| `outputs/national/` | Cleaned observations, holdout predictions, coefficients, metrics, insights and plots |
| `screenshots/` | VS Code execution and displayed outputs |

The project uses Go 1.20 or newer and the standard library. From the project directory, `go run .` regenerates the national outputs. `go test -v ./...` runs the tests. The program accepts `-train-end` for a different chronological split.

The national loader selects the specified country and indicator, trims field whitespace, collapses identical duplicate years and rejects conflicting records, invalid values and year gaps. Annual change is computed against the previous observed year. An undefined percentage is left blank.

The default run uses 1971–2014 target years for both regressions, with 1970 supplying the initial lag. The holdout is 2015–2022. The predictor for lag-based models is the latest available observed annual total. Previous holdout observations enter only as lags after their year, and the fitted coefficients stay fixed. The program compares these predictions against observed national emissions using MAE, RMSE and R².

## District data and coverage

The supplied data has national coverage. The district code was verified with synthetic test fixtures. Real spatial matches and district summaries require the lecturer’s companion datasets and conversion to the schemas below. District CO2 estimates would also need observed district-level CO2 targets. The national total is kept at its original geographic level.

| File | Required columns |
|---|---|
| `districts.csv` | district_id, district_name, latitude, longitude |
| `temperature.csv` | station_id, year, latitude, longitude, mean_temp_c |
| `demographics.csv` | district_id, year, population |
| `health.csv` | district_id, year, health_rate |

The `-district-input` flag accepts a directory containing those normalized CSV files. Locations use WGS 84 decimal degrees. Station means represent a calendar year. Health observations must use one consistently defined rate and unit across districts and years.

The district pipeline assigns each station to the nearest district centroid by Haversine distance, using a configurable radius that defaults to 50 km. Equidistant stations and stations outside the radius are recorded in the match audit. Centroid proximity can disagree with administrative boundaries. Within each district-year, station means receive equal weight, and missing values are preserved as blank fields in the panel. The summary gives means for the available years and a descriptive Pearson correlation for matched temperature and health observations with at least three paired years and variation in both measures.
