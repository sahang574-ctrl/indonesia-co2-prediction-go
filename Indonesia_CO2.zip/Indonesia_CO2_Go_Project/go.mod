module indonesia-emissions

go 1.20
