package main

import (
	"encoding/csv"
	"errors"
	"flag"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

type observation struct {
	year int
	co2  float64
}

type csvRow struct {
	line   int
	fields map[string]string
}

func main() {
	input := flag.String("input", "data/indonesia_co2.csv", "national CO2 CSV")
	output := flag.String("out", "outputs/national", "national output directory")
	trainEnd := flag.Int("train-end", 2014, "last training year")
	districtInput := flag.String("district-input", "", "directory containing standardized district CSVs")
	districtOut := flag.String("district-out", "outputs/district", "district output directory")
	radius := flag.Float64("match-km", 50, "maximum station-to-centroid distance")
	flag.Parse()

	if err := run(*input, *output, *trainEnd); err != nil {
		fail(err)
	}
	if *districtInput != "" {
		if err := runDistrict(*districtInput, *districtOut, *radius); err != nil {
			fail(err)
		}
		fmt.Println("District outputs:", *districtOut)
	}
}

func fail(err error) {
	fmt.Fprintln(os.Stderr, err)
	os.Exit(1)
}

func run(input, output string, trainEnd int) error {
	series, err := loadEmissions(input)
	if err != nil {
		return err
	}
	models, err := backtest(series, trainEnd)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(output, 0755); err != nil {
		return err
	}
	if err := writeNational(output, series, trainEnd, models); err != nil {
		return err
	}
	fmt.Printf("Indonesia CO2 | %d observations | %d-%d\n", len(series), series[0].year, series[len(series)-1].year)
	fmt.Printf("Holdout | %d-%d | %d one-year-ahead predictions per model\n", trainEnd+1, series[len(series)-1].year, len(models[0].predictions))
	fmt.Printf("%-17s %9s %9s %9s\n", "Model", "MAE", "RMSE", "R²")
	for _, model := range models {
		s := evaluate(model.predictions)
		fmt.Printf("%-17s %9.2f %9.2f %9s\n", model.name, s.mae, s.rmse, rSquared(s, 3))
	}
	fmt.Println("MAE and RMSE in Mt CO2e")
	fmt.Println("Outputs:", output)
	return nil
}

func readCSV(path string, required ...string) ([]csvRow, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	reader := csv.NewReader(file)
	headers, err := reader.Read()
	if err != nil {
		return nil, fmt.Errorf("%s: read header: %w", path, err)
	}
	seen := make(map[string]bool)
	for i, field := range headers {
		field = strings.TrimSpace(strings.TrimPrefix(field, "\uFEFF"))
		if field == "" || seen[field] {
			return nil, fmt.Errorf("%s: empty or duplicate header %q", path, field)
		}
		headers[i], seen[field] = field, true
	}
	for _, field := range required {
		if !seen[field] {
			return nil, fmt.Errorf("%s: missing column %q", path, field)
		}
	}
	var rows []csvRow
	for {
		values, err := reader.Read()
		if errors.Is(err, io.EOF) {
			break
		}
		if err != nil {
			return nil, fmt.Errorf("%s: %w", path, err)
		}
		line, _ := reader.FieldPos(0)
		fields := make(map[string]string, len(headers))
		for i, field := range headers {
			fields[field] = strings.TrimSpace(values[i])
		}
		rows = append(rows, csvRow{line, fields})
	}
	if len(rows) == 0 {
		return nil, fmt.Errorf("%s: missing data rows", path)
	}
	return rows, nil
}

func loadEmissions(path string) ([]observation, error) {
	rows, err := readCSV(path, "Country Code", "Indicator Code", "Year", "CO2_Mt_CO2e")
	if err != nil {
		return nil, err
	}
	byYear := make(map[int]float64)
	for _, row := range rows {
		f := row.fields
		if !strings.EqualFold(f["Country Code"], "IDN") || f["Indicator Code"] != "EN.GHG.CO2.MT.CE.AR5" {
			continue
		}
		year, validYear := parseYear(f["Year"])
		value, numeric := parseNumber(f["CO2_Mt_CO2e"])
		if !validYear || !numeric || value < 0 {
			return nil, fmt.Errorf("%s:%d: invalid year or emissions", path, row.line)
		}
		if previous, exists := byYear[year]; exists && previous != value {
			return nil, fmt.Errorf("%s:%d: conflicting values for %d", path, row.line, year)
		}
		byYear[year] = value
	}
	if len(byYear) == 0 {
		return nil, fmt.Errorf("%s: no records for the Indonesia CO2 indicator", path)
	}
	series := make([]observation, 0, len(byYear))
	for year, value := range byYear {
		series = append(series, observation{year, value})
	}
	sort.Slice(series, func(i, j int) bool { return series[i].year < series[j].year })
	for i := 1; i < len(series); i++ {
		if series[i].year != series[i-1].year+1 {
			return nil, fmt.Errorf("%s: missing annual observation after %d", path, series[i-1].year)
		}
	}
	return series, nil
}

func parseYear(raw string) (int, bool) {
	year, err := strconv.Atoi(raw)
	return year, err == nil && year >= 1800 && year <= 2200
}

func parseNumber(raw string) (float64, bool) {
	value, err := strconv.ParseFloat(raw, 64)
	return value, err == nil && !math.IsNaN(value) && !math.IsInf(value, 0)
}

func writeCSV(dir, name string, header []string, rows [][]string) error {
	return writeFile(dir, name, func(file *os.File) error {
		w := csv.NewWriter(file)
		if err := w.Write(header); err != nil {
			return err
		}
		return w.WriteAll(rows)
	})
}

func writeText(dir, name, content string) error {
	return writeFile(dir, name, func(file *os.File) error {
		_, err := file.WriteString(content)
		return err
	})
}

// Publish finished file contents through a rename in the same directory.
func writeFile(dir, name string, write func(*os.File) error) error {
	file, err := os.CreateTemp(dir, "."+name+"-*")
	if err != nil {
		return err
	}
	defer os.Remove(file.Name())
	writeErr := write(file)
	closeErr := file.Close()
	if writeErr != nil {
		return fmt.Errorf("%s: %w", name, writeErr)
	}
	if closeErr != nil {
		return fmt.Errorf("%s: %w", name, closeErr)
	}
	return os.Rename(file.Name(), filepath.Join(dir, name))
}

func fixed(v float64) string { return strconv.FormatFloat(v, 'f', 4, 64) }
