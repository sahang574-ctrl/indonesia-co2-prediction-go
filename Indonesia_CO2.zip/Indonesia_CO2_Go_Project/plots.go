package main

import (
	"fmt"
	"html"
	"math"
	"os"
	"strings"
)

type curve struct {
	label, color string
	points       []observation
}

func writePlots(dir string, data []observation, trainEnd int, models []model) error {
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	all := []curve{{"Observed emissions", "#087D72", data}}
	holdout := []curve{{"Observed", "#162D41", data[len(data)-len(models[0].predictions):]}}
	colors := []string{"#087D72", "#B45509", "#7344A3"}
	for i, m := range models {
		points := make([]observation, 0, len(m.predictions))
		for _, p := range m.predictions {
			points = append(points, observation{p.year, p.predicted})
		}
		holdout = append(holdout, curve{m.name, colors[i], points})
	}
	if err := writeText(dir, "annual_emissions.svg", plot("Indonesia’s annual CO2 emissions", "National total excluding land use, land-use change and forestry", all, trainEnd)); err != nil {
		return err
	}
	return writeText(dir, "holdout_predictions.svg", plot("One-year-ahead CO2 predictions", "Chronological holdout with fixed regression coefficients", holdout, 0))
}

func plot(title, subtitle string, curves []curve, cutoff int) string {
	years := curves[0].points
	start, end := years[0].year, years[len(years)-1].year
	lo, hi := 0.0, 0.0
	if len(curves) > 1 {
		lo, hi = years[0].co2, years[0].co2
	}
	for _, c := range curves {
		for _, p := range c.points {
			lo, hi = math.Min(lo, p.co2), math.Max(hi, p.co2)
		}
	}
	step := math.Max(50, math.Ceil((hi-lo)/350)*50)
	lo = step * math.Floor(lo/step)
	hi = math.Max(lo+step, step*math.Ceil(hi/step))
	x := func(year int) float64 { return 94 + 904*float64(year-start)/float64(end-start) }
	y := func(v float64) float64 { return 435 - 306*(v-lo)/(hi-lo) }
	var b strings.Builder
	fmt.Fprintf(&b, "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1056 536\" width=\"1056\" height=\"536\" role=\"img\"><title>%s</title>\n", html.EscapeString(title))
	b.WriteString("<rect width=\"1056\" height=\"536\" fill=\"#FAFAF7\"/><g font-family=\"Arial,sans-serif\" fill=\"#162D41\">\n")
	fmt.Fprintf(&b, "<text x=\"45\" y=\"50\" font-size=\"31\" font-weight=\"700\">%s</text><text x=\"45\" y=\"80\" font-size=\"17\">%s</text><text x=\"45\" y=\"112\" font-size=\"14\">Mt CO2e</text>\n", html.EscapeString(title), html.EscapeString(subtitle))
	for v := lo; v <= hi; v += step {
		fmt.Fprintf(&b, "<path d=\"M94 %.2fH998\" stroke=\"#D7E1DE\"/><text x=\"82\" y=\"%.2f\" text-anchor=\"end\" font-size=\"14\">%.0f</text>\n", y(v), y(v)+4, v)
	}
	label := func(year int) {
		fmt.Fprintf(&b, "<text x=\"%.2f\" y=\"460\" font-size=\"14\" text-anchor=\"middle\">%d</text>\n", x(year), year)
	}
	stride := 1
	if end-start > 12 {
		stride = 10 * int(math.Ceil(float64(end-start)/60))
	}
	for year := start; year <= end-1; year += stride {
		if end-year > stride/2 {
			label(year)
		}
	}
	label(end)
	if cutoff > start && cutoff < end {
		divider := (x(cutoff) + x(cutoff+1)) / 2
		anchor, offset := "start", 8.0
		if divider > 820 {
			anchor, offset = "end", -8
		}
		fmt.Fprintf(&b, "<path d=\"M%.2f 129V435\" stroke=\"#728087\" stroke-dasharray=\"4 5\"/><text x=\"%.2f\" y=\"150\" text-anchor=\"%s\" font-size=\"14\">Holdout begins %d</text>\n", divider, divider+offset, anchor, cutoff+1)
	}
	for i, c := range curves {
		dash := ""
		if i > 0 {
			dash = " stroke-dasharray=\"8 5\""
		}
		fmt.Fprintf(&b, "<polyline fill=\"none\" stroke=\"%s\" stroke-width=\"3\"%s points=\"", c.color, dash)
		for _, p := range c.points {
			fmt.Fprintf(&b, "%.2f,%.2f ", x(p.year), y(p.co2))
		}
		b.WriteString("\"/>\n")
		for _, p := range c.points {
			fmt.Fprintf(&b, "<circle cx=\"%.2f\" cy=\"%.2f\" r=\"3\" fill=\"%s\"/>\n", x(p.year), y(p.co2), c.color)
		}
		pos := 94 + i*223
		fmt.Fprintf(&b, "<path d=\"M%d 497h27\" stroke=\"%s\" stroke-width=\"3\"%s/><text x=\"%d\" y=\"502\" font-size=\"15\">%s</text>\n", pos, c.color, dash, pos+35, html.EscapeString(c.label))
	}
	b.WriteString("</g></svg>\n")
	return b.String()
}
