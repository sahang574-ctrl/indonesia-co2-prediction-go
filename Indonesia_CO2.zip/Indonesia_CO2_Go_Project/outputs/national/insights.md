# Indonesia’s national CO2 emissions

The supplied data contain 53 consecutive years from 1970 to 2022. The indicator (EN.GHG.CO2.MT.CE.AR5) measures national CO2 emissions excluding land use, land-use change and forestry, in Mt CO2e.

- Emissions rose from **31.1237 Mt CO2e in 1970** to **722.6996 Mt CO2e in 2022**. The net change was +691.5759 Mt CO2e.
- The largest annual increase was **+100.0128 Mt CO2e in 2022**. The smallest annual change was **-41.2853 Mt CO2e in 2020**.

## Model performance

The OLS models used 1971–2014 target years. The holdout covered 2015–2022. Lagged models use the previous observed year for each one-year-ahead prediction. Model coefficients remain fixed after training.

| Model | MAE (Mt CO2e) | RMSE (Mt CO2e) | R² |
|---|---:|---:|---:|
| Persistence | 38.85 | 48.33 | 0.493 |
| Year trend OLS | 69.54 | 82.96 | -0.494 |
| Lag-1 OLS | 32.28 | 40.87 | 0.637 |

**Lag-1 OLS** had the lowest RMSE (**40.87 Mt CO2e**) on this holdout. The fitted time trend was 11.41 Mt CO2e per year. In the lag regression, an extra 1 Mt CO2e in the previous year increases the fitted next-year value by 1.0211 Mt CO2e. These are descriptive relationships, and the scores depend on a single holdout of 8 years.

## Geographic and data coverage

The source reports one national total per year. District emissions, climate and health relationships require the lecturer’s district, coordinate, temperature, demographics and health datasets.
