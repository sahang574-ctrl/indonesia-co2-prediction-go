package main

import (
	"math"
	"os"
	"path/filepath"
	"testing"
)

func TestOLS(t *testing.T) {
	m, err := fitOLS([]float64{1, 2, 3}, []float64{5, 7, 9})
	if err != nil || m != (equation{3, 2}) || m.predict(4) != 11 {
		t.Fatalf("expected 3+2x, got %+v, err=%v", m, err)
	}
}

func TestIndonesiaHoldout(t *testing.T) {
	data, err := loadEmissions("data/indonesia_co2.csv")
	if err != nil {
		t.Fatal(err)
	}
	if len(data) != 53 || data[0] != (observation{1970, 31.1237}) || data[52] != (observation{2022, 722.6996}) {
		t.Fatal("supplied data endpoints or row count changed")
	}
	models, err := backtest(data, 2014)
	if err != nil {
		t.Fatal(err)
	}
	p := models[0].predictions
	if len(p) != 8 || p[0].predicted != 505.0762 || p[7].predicted != 622.6868 {
		t.Fatal("persistence must use each actual prior year")
	}
	for i, want := range []float64{48.3250, 82.9646, 40.8707} {
		if got := evaluate(models[i].predictions).rmse; math.Abs(got-want) > .012 {
			t.Fatalf("%s RMSE = %.5f", models[i].name, got)
		}
	}
	changed := append([]observation(nil), data...)
	changed[45].co2 += 10
	recalculated, err := backtest(changed, 2014)
	if err != nil {
		t.Fatal(err)
	}
	if recalculated[2].fit != models[2].fit || recalculated[2].predictions[0].predicted != models[2].predictions[0].predicted {
		t.Fatal("the current holdout target leaked into model fitting or prediction")
	}
}

func TestDistrictMatchingAndJoin(t *testing.T) {
	in, out := t.TempDir(), t.TempDir()
	for name, content := range map[string]string{
		"districts.csv":    "district_id,district_name,latitude,longitude\n01,Alpha,0,0\n02,Beta,0,2\n",
		"temperature.csv":  "station_id,year,latitude,longitude,mean_temp_c\ns1,2020,0,0.1,20\ns1,2020,0,0.1,20\ns2,2020,0,0.2,24\ns3,2020,0,1,10\ns4,2020,0,5,18\ns1,2021,0,0.1,21\n",
		"demographics.csv": "district_id,year,population\n01,2020,100\n02,2020,200\n",
		"health.csv":       "district_id,year,health_rate\n01,2020,3\n01,2021,NA\n02,2020,5\n",
	} {
		if err := os.WriteFile(filepath.Join(in, name), []byte(content), 0600); err != nil {
			t.Fatal(err)
		}
	}
	if err := runDistrict(in, out, 150); err != nil {
		t.Fatal(err)
	}
	rows, err := readCSV(filepath.Join(out, "district_year.csv"), "mean_temp_c", "station_count")
	if err != nil {
		t.Fatal(err)
	}
	if len(rows) != 3 || rows[0].fields["mean_temp_c"] != "22.0000" || rows[0].fields["station_count"] != "2" || rows[1].fields["health_rate"] != "" || rows[2].fields["mean_temp_c"] != "" {
		t.Fatalf("unexpected join: %+v", rows)
	}
	matches, err := readCSV(filepath.Join(out, "station_matches.csv"), "status")
	if err != nil {
		t.Fatal(err)
	}
	if len(matches) != 4 || matches[2].fields["status"] != "ambiguous_tie" || matches[3].fields["status"] != "outside_radius" {
		t.Fatalf("unexpected audit: %+v", matches)
	}
	if d := haversine(point{0, 0}, point{0, 1}); math.Abs(d-111.19508) > .001 {
		t.Fatalf("unexpected distance %.6f", d)
	}
}
