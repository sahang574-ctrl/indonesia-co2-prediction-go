package main

import (
	"fmt"
	"math"
	"path/filepath"
	"strconv"
)

type equation struct {
	intercept, slope float64
}

func (e equation) predict(x float64) float64 { return e.intercept + e.slope*x }

func fitOLS(x, y []float64) (equation, error) {
	if len(x) != len(y) || len(x) < 2 {
		return equation{}, fmt.Errorf("OLS requires at least two paired observations")
	}
	mx, my := mean(x), mean(y)
	var xx, xy float64
	for i, v := range x {
		xx += (v - mx) * (v - mx)
		xy += (v - mx) * (y[i] - my)
	}
	if xx == 0 {
		return equation{}, fmt.Errorf("OLS predictor has no variation")
	}
	slope := xy / xx
	return equation{my - slope*mx, slope}, nil
}

func mean(values []float64) float64 {
	var sum float64
	for _, value := range values {
		sum += value
	}
	return sum / float64(len(values))
}

type prediction struct {
	year              int
	actual, predicted float64
}

type model struct {
	name, feature string
	fit           equation
	predictions   []prediction
}

type scores struct{ mae, rmse, r2 float64 }

func backtest(series []observation, trainEnd int) ([]model, error) {
	split := 0
	for split < len(series) && series[split].year <= trainEnd {
		split++
	}
	if split < 4 || len(series)-split < 2 || series[split-1].year != trainEnd {
		return nil, fmt.Errorf("cutoff must leave at least four training years and two later years")
	}
	start := series[0].year
	var years, lags, targets []float64
	// Both regressions are fitted on the same target years.
	for i := 1; i < split; i++ {
		years = append(years, float64(series[i].year-start))
		lags = append(lags, series[i-1].co2)
		targets = append(targets, series[i].co2)
	}
	trend, err := fitOLS(years, targets)
	if err != nil {
		return nil, err
	}
	lag, err := fitOLS(lags, targets)
	if err != nil {
		return nil, err
	}
	models := []model{
		{name: "Persistence", feature: "prior_year_co2_mt_co2e", fit: equation{0, 1}},
		{name: "Year trend OLS", feature: fmt.Sprintf("year_minus_%d", start), fit: trend},
		{name: "Lag-1 OLS", feature: "prior_year_co2_mt_co2e", fit: lag},
	}
	for i := split; i < len(series); i++ {
		row := series[i]
		prior := series[i-1].co2
		features := []float64{prior, float64(row.year - start), prior}
		for j := range models {
			m := &models[j]
			m.predictions = append(m.predictions, prediction{row.year, row.co2, m.fit.predict(features[j])})
		}
	}
	return models, nil
}

func evaluate(rows []prediction) scores {
	n := float64(len(rows))
	var sum, absolute, ssResidual, ssTotal float64
	for _, row := range rows {
		sum += row.actual
	}
	avg := sum / n
	for _, row := range rows {
		residual, deviation := row.actual-row.predicted, row.actual-avg
		absolute += math.Abs(residual)
		ssResidual += residual * residual
		ssTotal += deviation * deviation
	}
	r2 := math.NaN()
	if ssTotal > 0 {
		r2 = 1 - ssResidual/ssTotal
	}
	return scores{absolute / n, math.Sqrt(ssResidual / n), r2}
}

func rSquared(s scores, digits int) string {
	if math.IsNaN(s.r2) {
		return ""
	}
	return strconv.FormatFloat(s.r2, 'f', digits, 64)
}

func writeNational(dir string, series []observation, trainEnd int, models []model) error {
	var cleaned, forecasts, metrics, coefficients [][]string
	var rise, fall float64
	var riseYear, fallYear int
	for i, row := range series {
		var deltaText, pct string
		if i > 0 {
			prev := series[i-1].co2
			delta := row.co2 - prev
			deltaText = fixed(delta)
			if prev > 0 {
				pct = fixed(100 * delta / prev)
			}
			if i == 1 || delta > rise {
				rise, riseYear = delta, row.year
			}
			if i == 1 || delta < fall {
				fall, fallYear = delta, row.year
			}
		}
		cleaned = append(cleaned, []string{"IDN", strconv.Itoa(row.year), fixed(row.co2), deltaText, pct})
	}
	best := models[0].name
	bestRMSE := math.Inf(1)
	for _, m := range models {
		s := evaluate(m.predictions)
		if s.rmse < bestRMSE {
			best, bestRMSE = m.name, s.rmse
		}
		metrics = append(metrics, []string{m.name, strconv.Itoa(len(m.predictions)), fixed(s.mae), fixed(s.rmse), rSquared(s, 4)})
		coefficients = append(coefficients, []string{m.name, m.feature, fixed(m.fit.intercept), fixed(m.fit.slope)})
		for _, p := range m.predictions {
			forecasts = append(forecasts, []string{m.name, strconv.Itoa(p.year), fixed(p.actual), fixed(p.predicted), fixed(p.actual - p.predicted)})
		}
	}
	for _, table := range []struct {
		name   string
		header []string
		rows   [][]string
	}{
		{"annual_co2_clean.csv", []string{"country_code", "year", "co2_mt_co2e", "yoy_change_mt_co2e", "yoy_change_pct"}, cleaned},
		{"model_metrics.csv", []string{"model", "holdout_years", "mae_mt_co2e", "rmse_mt_co2e", "r_squared"}, metrics},
		{"model_coefficients.csv", []string{"model", "predictor", "intercept", "slope"}, coefficients},
		{"holdout_predictions.csv", []string{"model", "year", "actual_mt_co2e", "predicted_mt_co2e", "actual_minus_prediction_mt_co2e"}, forecasts},
	} {
		if err := writeCSV(dir, table.name, table.header, table.rows); err != nil {
			return err
		}
	}
	first, last := series[0], series[len(series)-1]
	report := fmt.Sprintf(`# Indonesia’s national CO2 emissions

The supplied data contain %d consecutive years from %d to %d. The indicator (EN.GHG.CO2.MT.CE.AR5) measures national CO2 emissions excluding land use, land-use change and forestry, in Mt CO2e.

- Emissions rose from **%.4f Mt CO2e in %d** to **%.4f Mt CO2e in %d**. The net change was %+.4f Mt CO2e.
- The largest annual increase was **%+.4f Mt CO2e in %d**. The smallest annual change was **%+.4f Mt CO2e in %d**.

## Model performance

The OLS models used %d–%d target years. The holdout covered %d–%d. Lagged models use the previous observed year for each one-year-ahead prediction. Model coefficients remain fixed after training.

| Model | MAE (Mt CO2e) | RMSE (Mt CO2e) | R² |
|---|---:|---:|---:|
`, len(series), first.year, last.year, first.co2, first.year, last.co2, last.year, last.co2-first.co2, rise, riseYear, fall, fallYear, first.year+1, trainEnd, trainEnd+1, last.year)
	for _, m := range models {
		s := evaluate(m.predictions)
		r2 := rSquared(s, 3)
		if r2 == "" {
			r2 = "undefined"
		}
		report += fmt.Sprintf("| %s | %.2f | %.2f | %s |\n", m.name, s.mae, s.rmse, r2)
	}
	report += fmt.Sprintf(`
**%s** had the lowest RMSE (**%.2f Mt CO2e**) on this holdout. The fitted time trend was %.2f Mt CO2e per year. In the lag regression, an extra 1 Mt CO2e in the previous year increases the fitted next-year value by %.4f Mt CO2e. These are descriptive relationships, and the scores depend on a single holdout of %d years.

## Geographic and data coverage

The source reports one national total per year. District emissions, climate and health relationships require the lecturer’s district, coordinate, temperature, demographics and health datasets.
`, best, bestRMSE, models[1].fit.slope, models[2].fit.slope, len(models[0].predictions))
	if err := writeText(dir, "insights.md", report); err != nil {
		return err
	}
	return writePlots(filepath.Join(dir, "plots"), series, trainEnd, models)
}
