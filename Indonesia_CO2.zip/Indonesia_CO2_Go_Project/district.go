package main

import (
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strconv"
)

type point struct{ lat, lon float64 }
type district struct {
	id, name string
	center   point
}
type yearKey struct {
	id   string
	year int
}
type aggregate struct {
	count int
	sum   float64
}
type match struct {
	district string
	km       float64
	status   string
}

func coordinates(row csvRow) (point, bool) {
	lat, validLat := parseNumber(row.fields["latitude"])
	lon, validLon := parseNumber(row.fields["longitude"])
	return point{lat, lon}, validLat && validLon && math.Abs(lat) <= 90 && math.Abs(lon) <= 180
}

func haversine(from, to point) float64 {
	const rad = math.Pi / 180
	a, b := math.Sin((to.lat-from.lat)*rad/2), math.Sin((to.lon-from.lon)*rad/2)
	v := a*a + math.Cos(from.lat*rad)*math.Cos(to.lat*rad)*b*b
	return 2 * 6371.0088 * math.Asin(math.Sqrt(math.Min(1, math.Max(0, v))))
}

func nearest(station point, districts []district, radius float64) match {
	best := match{km: math.Inf(1), status: "outside_radius"}
	tied := false
	for _, d := range districts {
		km := haversine(station, d.center)
		if math.Abs(km-best.km) <= 1e-8 {
			tied = true
		} else if km < best.km {
			best.district, best.km, tied = d.id, km, false
		}
	}
	switch {
	case best.km > radius:
		best.district = ""
	case tied:
		best.district, best.status = "", "ambiguous_tie"
	default:
		best.status = "matched"
	}
	return best
}

func runDistrict(input, output string, radius float64) error {
	if radius <= 0 || math.IsNaN(radius) || math.IsInf(radius, 0) {
		return fmt.Errorf("match radius must be finite and positive")
	}
	rows, err := readCSV(filepath.Join(input, "districts.csv"), "district_id", "district_name", "latitude", "longitude")
	if err != nil {
		return err
	}
	var districts []district
	names := make(map[string]string)
	for _, row := range rows {
		id, name := row.fields["district_id"], row.fields["district_name"]
		p, valid := coordinates(row)
		if id == "" || name == "" || !valid || names[id] != "" {
			return fmt.Errorf("districts.csv:%d: invalid or duplicate district", row.line)
		}
		names[id] = name
		districts = append(districts, district{id, name, p})
	}
	pop, err := loadDistrictValues(input, "demographics.csv", "population", names)
	if err != nil {
		return err
	}
	health, err := loadDistrictValues(input, "health.csv", "health_rate", names)
	if err != nil {
		return err
	}
	temps, audit, err := matchWeather(input, districts, radius)
	if err != nil {
		return err
	}

	keys := make(map[yearKey]bool)
	for k := range pop {
		keys[k] = true
	}
	for k := range health {
		keys[k] = true
	}
	for k := range temps {
		keys[k] = true
	}
	ordered := make([]yearKey, 0, len(keys))
	for k := range keys {
		ordered = append(ordered, k)
	}
	sort.Slice(ordered, func(i, j int) bool {
		if ordered[i].id == ordered[j].id {
			return ordered[i].year < ordered[j].year
		}
		return ordered[i].id < ordered[j].id
	})
	type districtStats struct {
		allTemps, allHealth, pairedTemps, pairedHealth []float64
	}
	stats := make(map[string]*districtStats)
	var panel, summary [][]string
	for _, k := range ordered {
		s := stats[k.id]
		if s == nil {
			s = &districtStats{}
			stats[k.id] = s
		}
		w := temps[k]
		h, hasHealth := health[k]
		var tempText, popText, healthText string
		if w.count > 0 {
			value := w.sum / float64(w.count)
			tempText = fixed(value)
			s.allTemps = append(s.allTemps, value)
			if hasHealth {
				s.pairedTemps = append(s.pairedTemps, value)
				s.pairedHealth = append(s.pairedHealth, h)
			}
		}
		if v, ok := pop[k]; ok {
			popText = strconv.FormatFloat(v, 'f', 0, 64)
		}
		if hasHealth {
			healthText = fixed(h)
			s.allHealth = append(s.allHealth, h)
		}
		panel = append(panel, []string{k.id, names[k.id], strconv.Itoa(k.year), tempText, strconv.Itoa(w.count), popText, healthText})
	}
	sort.Slice(districts, func(i, j int) bool { return districts[i].id < districts[j].id })
	for _, d := range districts {
		s := stats[d.id]
		if s == nil {
			s = &districtStats{}
		}
		summary = append(summary, []string{d.id, d.name, optionalMean(s.allTemps), optionalMean(s.allHealth),
			strconv.Itoa(len(s.pairedTemps)), pearson(s.pairedTemps, s.pairedHealth)})
	}

	if err := os.MkdirAll(output, 0755); err != nil {
		return err
	}
	if err := writeCSV(output, "station_matches.csv", []string{"station_id", "latitude", "longitude", "district_id", "nearest_km", "status"}, audit); err != nil {
		return err
	}
	if err := writeCSV(output, "district_year.csv", []string{"district_id", "district_name", "year", "mean_temp_c", "station_count", "population", "health_rate"}, panel); err != nil {
		return err
	}
	return writeCSV(output, "district_summary.csv", []string{"district_id", "district_name", "mean_temp_c", "mean_health_rate", "paired_years", "temp_health_pearson_r"}, summary)
}

func loadDistrictValues(dir, file, field string, names map[string]string) (map[yearKey]float64, error) {
	rows, err := readCSV(filepath.Join(dir, file), "district_id", "year", field)
	if err != nil {
		return nil, err
	}
	values := make(map[yearKey]float64)
	for _, row := range rows {
		id := row.fields["district_id"]
		year, validYear := parseYear(row.fields["year"])
		if names[id] == "" || !validYear {
			return nil, fmt.Errorf("%s:%d: invalid district or year", file, row.line)
		}
		raw := row.fields[field]
		if raw == "" || raw == "NA" {
			continue
		}
		v, valid := parseNumber(raw)
		if !valid || v < 0 || (field == "population" && math.Trunc(v) != v) {
			return nil, fmt.Errorf("%s:%d: invalid %s", file, row.line, field)
		}
		k := yearKey{id, year}
		if old, exists := values[k]; exists && old != v {
			return nil, fmt.Errorf("%s:%d: conflicting %s values for district and year", file, row.line, field)
		}
		values[k] = v
	}
	return values, nil
}

func matchWeather(dir string, districts []district, radius float64) (map[yearKey]aggregate, [][]string, error) {
	rows, err := readCSV(filepath.Join(dir, "temperature.csv"), "station_id", "year", "latitude", "longitude", "mean_temp_c")
	if err != nil {
		return nil, nil, err
	}
	points := make(map[string]point)
	matches := make(map[string]match)
	stationYears := make(map[yearKey]float64)
	weather := make(map[yearKey]aggregate)
	var audit [][]string
	for _, row := range rows {
		station := row.fields["station_id"]
		p, validPoint := coordinates(row)
		year, validYear := parseYear(row.fields["year"])
		if station == "" || !validPoint || !validYear {
			return nil, nil, fmt.Errorf("temperature.csv:%d: invalid station, coordinate or year", row.line)
		}
		old, exists := points[station]
		if exists && old != p {
			return nil, nil, fmt.Errorf("temperature.csv:%d: inconsistent coordinates for station", row.line)
		}
		if !exists {
			m := nearest(p, districts, radius)
			points[station], matches[station] = p, m
			audit = append(audit, []string{station, fixed(p.lat), fixed(p.lon), m.district, fixed(m.km), m.status})
		}
		raw := row.fields["mean_temp_c"]
		if raw == "" || raw == "NA" {
			continue
		}
		v, valid := parseNumber(raw)
		if !valid || v < -90 || v > 65 {
			return nil, nil, fmt.Errorf("temperature.csv:%d: invalid annual temperature", row.line)
		}
		k := yearKey{station, year}
		if old, exists := stationYears[k]; exists {
			if old != v {
				return nil, nil, fmt.Errorf("temperature.csv:%d: conflicting station-year values", row.line)
			}
			continue
		}
		stationYears[k] = v
		if id := matches[station].district; id != "" {
			key := yearKey{id, year}
			existing := weather[key]
			existing.count++
			existing.sum += v
			weather[key] = existing
		}
	}
	sort.Slice(audit, func(i, j int) bool { return audit[i][0] < audit[j][0] })
	return weather, audit, nil
}

func optionalMean(values []float64) string {
	if len(values) == 0 {
		return ""
	}
	return fixed(mean(values))
}

func pearson(x, y []float64) string {
	if len(x) < 3 {
		return ""
	}
	mx, my := mean(x), mean(y)
	var xx, yy, xy float64
	for i, v := range x {
		dx, dy := v-mx, y[i]-my
		xx += dx * dx
		yy += dy * dy
		xy += dx * dy
	}
	if xx == 0 || yy == 0 {
		return ""
	}
	return fixed(xy / math.Sqrt(xx*yy))
}
